const express = require("express");
const router = express.Router();
const Rental = require("../models/Appointment");
const Server = require("../models/Doctor");

// Получить список аренд пользователя
router.get("/user/:userId", async (req, res) => {
  try {
    const rentals = await Rental.findAll({
      where: { userId: req.params.userId },
      include: [
        {
          model: Server,
          attributes: ["game", "slots"],
        },
      ],
    });
    res.json(rentals);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Получить информацию об аренде
router.get("/:id", async (req, res) => {
  try {
    const rental = await Rental.findByPk(req.params.id, {
      include: [
        {
          model: Server,
          attributes: ["game", "slots"],
        },
      ],
    });

    if (!rental) {
      return res.status(404).json({ error: "Аренда не найдена" });
    }

    res.json(rental);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Отменить аренду
router.delete("/:id", async (req, res) => {
  try {
    const rental = await Rental.findByPk(req.params.id);

    if (!rental) {
      return res.status(404).json({ error: "Аренда не найдена" });
    }

    const server = await Server.findByPk(rental.serverId);
    if (server) {
      server.status = "available";
      await server.save();
    }

    await rental.destroy();
    res.json({ message: "Аренда успешно отменена" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
