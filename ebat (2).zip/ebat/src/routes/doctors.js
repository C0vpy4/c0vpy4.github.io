const express = require("express");
const router = express.Router();
const Server = require("../models/Doctor");
const Rental = require("../models/Appointment");

// Получить список всех серверов
router.get("/", async (req, res) => {
  try {
    const servers = await Server.findAll();
    res.json(servers);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Получить список доступных серверов
router.get("/available", async (req, res) => {
  try {
    const servers = await Server.findAll({
      where: { status: "available" },
    });
    res.json(servers);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Арендовать сервер
router.post("/:id/rent", async (req, res) => {
  try {
    const { userId, endDate } = req.body;
    const serverId = req.params.id;

    const server = await Server.findByPk(serverId);
    if (!server) {
      return res.status(404).json({ error: "Сервер не найден" });
    }

    if (server.status !== "available") {
      return res.status(400).json({ error: "Сервер уже арендован" });
    }

    const rental = await Rental.create({
      serverId,
      userId,
      endDate: new Date(endDate),
    });

    server.status = "rented";
    await server.save();

    res.status(201).json(rental);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Продлить аренду
router.put("/:id/extend", async (req, res) => {
  try {
    const { endDate } = req.body;
    const serverId = req.params.id;

    const rental = await Rental.findOne({
      where: { serverId },
    });

    if (!rental) {
      return res.status(404).json({ error: "Аренда не найдена" });
    }

    rental.endDate = new Date(endDate);
    await rental.save();

    res.json(rental);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
