const { DataTypes } = require("sequelize");
const sequelize = require("../db");

const Rental = sequelize.define("Rental", {
  serverId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: "Servers",
      key: "id",
    },
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: "Users",
      key: "id",
    },
  },
  endDate: {
    type: DataTypes.DATE,
    allowNull: false,
  },
});

module.exports = Rental;
