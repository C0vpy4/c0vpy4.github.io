const { DataTypes } = require("sequelize");
const sequelize = require("../db");

const Server = sequelize.define("Server", {
  game: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  slots: {
    type: DataTypes.INTEGER,
    allowNull: false,
    validate: {
      min: 1,
    },
  },
  status: {
    type: DataTypes.ENUM("available", "rented"),
    defaultValue: "available",
    allowNull: false,
  },
});

module.exports = Server;
