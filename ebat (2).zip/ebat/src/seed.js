const sequelize = require("./db");
const User = require("./models/User");
const Server = require("./models/Doctor"); // Используем переименованную модель
const Rental = require("./models/Appointment"); // Используем переименованную модель
// Функция для генерации временных слотов с 10:00 до 20:00 с интервалом 30 минут
function generateTimeSlots() {
  const slots = [];
  for (let hour = 10; hour < 20; hour++) {
    const formattedHour = hour.toString().padStart(2, "0");
    slots.push(`${formattedHour}:00-${formattedHour}:30`);
    slots.push(
      `${formattedHour}:30-${(hour + 1).toString().padStart(2, "0")}:00`
    );
  }
  return slots;
}

async function seedDatabase() {
  try {
    await sequelize.sync({ force: true });

    console.log("База данных синхронизирована");

    // Создаем тестовых пользователей
    const users = await User.bulkCreate([
      {
        email: "user1@example.com",
        password: "123456",
      },
      {
        email: "user2@example.com",
        password: "123456",
      },
    ]);
    console.log(`Создано ${users.length} пользователей`);

    // Создаем тестовые серверы
    const servers = await Server.bulkCreate([
      {
        game: "Counter-Strike 2",
        slots: 32,
        status: "available",
      },
      {
        game: "Minecraft",
        slots: 50,
        status: "available",
      },
      {
        game: "Team Fortress 2",
        slots: 24,
        status: "available",
      },
    ]);
    console.log(`Создано ${servers.length} серверов`);

    // Создаем тестовые аренды
    const rentals = await Rental.bulkCreate([
      {
        serverId: 1,
        userId: 1,
        endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // +7 дней
      },
    ]);
    console.log(`Создано ${rentals.length} аренд`);

    // Обновляем статус арендованного сервера
    const server1 = await Server.findByPk(1);
    server1.status = "rented";
    await server1.save();

    console.log("Заполнение базы данных завершено успешно");
  } catch (error) {
    console.error("Ошибка при заполнении базы данных:", error);
  } finally {
    await sequelize.close();
  }
}

seedDatabase();
