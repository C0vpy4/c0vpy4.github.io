const express = require("express");
const router = express.Router();
const Product = require("../models/Doctor");
const { Purchase } = require("../models/Appointment");
const User = require("../models/User");
const Category = require("../models/Category");

// Получить список всех товаров
router.get("/", async (req, res) => {
  try {
    const products = await Product.findAll({
      include: [
        {
          model: Category,
          attributes: ["name"],
        },
      ],
      attributes: ["id", "name", "price", "categoryId"],
    });
    res.json(products);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Получить товар по ID
router.get("/:id", async (req, res) => {
  try {
    const product = await Product.findByPk(req.params.id, {
      include: [
        {
          model: Category,
          attributes: ["name"],
        },
      ],
    });

    if (!product) {
      return res.status(404).json({ error: "Товар не найден" });
    }

    res.json(product);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Купить товар
router.post("/:id/buy", async (req, res) => {
  try {
    const { userId } = req.body;
    const productId = req.params.id;

    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({ error: "Пользователь не найден" });
    }

    const product = await Product.findByPk(productId);
    if (!product) {
      return res.status(404).json({ error: "Товар не найден" });
    }

    if (user.balance < product.price) {
      return res.status(400).json({ error: "Недостаточно средств на балансе" });
    }

    // Списываем деньги
    user.balance = parseFloat(user.balance) - parseFloat(product.price);
    await user.save();

    // Создаем запись о покупке
    const purchase = await Purchase.create({
      productId,
      userId,
      price: product.price,
      purchaseDate: new Date(),
    });

    res.json({
      message: "Покупка успешно совершена",
      downloadLink: product.digitalFile,
      newBalance: user.balance,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Получить историю покупок пользователя
router.get("/user/:userId/purchases", async (req, res) => {
  try {
    const purchases = await Purchase.findAll({
      where: { userId: req.params.userId },
      include: [
        {
          model: Product,
          attributes: ["name", "digitalFile"],
        },
      ],
      order: [["purchaseDate", "DESC"]],
    });
    res.json(purchases);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
