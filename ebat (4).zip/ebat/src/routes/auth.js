const express = require("express");
const router = express.Router();
const User = require("../models/User");

// Регистрация
router.post("/register", async (req, res) => {
  try {
    const { email, password } = req.body;

    // Проверяем наличие всех необходимых полей
    if (!email || !password) {
      return res.status(400).json({
        error: "Все поля обязательны для заполнения",
        details: {
          email: !email ? "Email обязателен" : null,
          password: !password ? "Пароль обязателен" : null,
        },
      });
    }

    // Проверяем формат email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({
        error: "Неверный формат email",
      });
    }

    // Проверяем длину пароля
    if (password.length < 6) {
      return res.status(400).json({
        error: "Пароль слишком короткий",
        details: "Пароль должен содержать минимум 6 символов",
      });
    }

    const user = await User.create({ email, password });
    res.status(201).json({
      message: "Пользователь успешно зарегистрирован",
      userId: user.id,
    });
  } catch (error) {
    if (error.name === "SequelizeUniqueConstraintError") {
      return res.status(400).json({
        error: "Пользователь с таким email уже существует",
      });
    }
    res.status(400).json({ error: error.message });
  }
});

// Вход
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ where: { email } });

    if (!user) {
      return res.status(401).json({ error: "Неверный email или пароль" });
    }

    const isValidPassword = await user.validatePassword(password);
    if (!isValidPassword) {
      return res.status(401).json({ error: "Неверный email или пароль" });
    }

    res.json({
      message: "Успешный вход",
      userId: user.id,
      balance: user.balance,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Пополнение баланса
router.post("/balance", async (req, res) => {
  try {
    const { userId, amount } = req.body;
    const user = await User.findByPk(userId);

    if (!user) {
      return res.status(404).json({ error: "Пользователь не найден" });
    }

    if (amount <= 0) {
      return res.status(400).json({ error: "Сумма должна быть положительной" });
    }

    user.balance = parseFloat(user.balance) + parseFloat(amount);
    await user.save();

    res.json({
      message: "Баланс успешно пополнен",
      newBalance: user.balance,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
