const express = require("express");
const router = express.Router();
const Rental = require("../models/Appointment");
const Scooter = require("../models/Doctor");
const User = require("../models/User");
const Category = require("../models/Category");
const Product = require("../models/Doctor");

// Получить список всех категорий
router.get("/", async (req, res) => {
  try {
    const categories = await Category.findAll();
    res.json(categories);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Получить товары по категории
router.get("/:id/products", async (req, res) => {
  try {
    const products = await Product.findAll({
      where: { categoryId: req.params.id },
      include: [
        {
          model: Category,
          attributes: ["name"],
        },
      ],
      attributes: ["id", "name", "price"],
    });
    res.json(products);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Получить список аренд пользователя
router.get("/user/:userId", async (req, res) => {
  try {
    const rentals = await Rental.findAll({
      where: { userId: req.params.userId },
      include: [
        {
          model: Scooter,
          attributes: ["coordinates"],
        },
      ],
      order: [["startTime", "DESC"]],
    });
    res.json(rentals);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Получить информацию об аренде
router.get("/:id", async (req, res) => {
  try {
    const rental = await Rental.findByPk(req.params.id, {
      include: [
        {
          model: Scooter,
          attributes: ["coordinates"],
        },
        {
          model: User,
          attributes: ["name", "phone"],
        },
      ],
    });

    if (!rental) {
      return res.status(404).json({ error: "Аренда не найдена" });
    }

    res.json(rental);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Отменить аренду
router.delete("/:id", async (req, res) => {
  try {
    const rental = await Rental.findByPk(req.params.id);

    if (!rental) {
      return res.status(404).json({ error: "Аренда не найдена" });
    }

    const scooter = await Scooter.findByPk(rental.scooterId);
    if (scooter) {
      scooter.status = "available";
      await scooter.save();
    }

    await rental.destroy();
    res.json({ message: "Аренда успешно отменена" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
