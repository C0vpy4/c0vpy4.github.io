const Product = require("./Doctor");
const Category = require("./Category");
const { Purchase } = require("./Appointment");
const User = require("./User");

// Определяем связи
Product.belongsTo(Category, { foreignKey: "categoryId" });
Category.hasMany(Product, { foreignKey: "categoryId" });

Product.hasMany(Purchase, { foreignKey: "productId" });
Purchase.belongsTo(Product, { foreignKey: "productId" });

Purchase.belongsTo(User, { foreignKey: "userId" });
User.hasMany(Purchase, { foreignKey: "userId" });

module.exports = {
  Product,
  Category,
  Purchase,
  User,
};
