const { DataTypes } = require("sequelize");
const sequelize = require("../db");
const Product = require("./Doctor");
const User = require("./User");

const Rental = sequelize.define("Rental", {
  scooterId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: "Scooters",
      key: "id",
    },
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: "Users",
      key: "id",
    },
  },
  startTime: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW,
  },
  endTime: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  cost: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: true,
  },
});

const Purchase = sequelize.define("Purchase", {
  productId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: "Products",
      key: "id",
    },
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: "Users",
      key: "id",
    },
  },
  purchaseDate: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW,
  },
  price: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
  },
});

// Определяем связи
Purchase.belongsTo(Product, { foreignKey: "productId" });
Purchase.belongsTo(User, { foreignKey: "userId" });

module.exports = { Rental, Purchase };
