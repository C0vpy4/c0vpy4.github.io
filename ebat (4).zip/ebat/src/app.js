const express = require("express");
const path = require("path");
const bodyParser = require("body-parser"); // Убедитесь, что body-parser установлен
const sequelize = require("./db");
const config = require("./config");
const authRoutes = require("./routes/auth");
const productRoutes = require("./routes/doctors");
const categoryRoutes = require("./routes/appointments");

// Загружаем все модели и их связи
require("./models/associations");

const app = express();

// Добавляем raw parser для обработки всех запросов как JSON
app.use((req, res, next) => {
  if (
    req.method === "POST" &&
    !req.is("application/json") &&
    req.headers["content-length"]
  ) {
    let data = "";
    req.setEncoding("utf8");
    req.on("data", (chunk) => {
      data += chunk;
    });
    req.on("end", () => {
      try {
        req.body = JSON.parse(data);
        console.log("Принудительно обработан JSON:", req.body);
        next();
      } catch (e) {
        console.error("Ошибка парсинга JSON:", e);
        next();
      }
    });
  } else {
    next();
  }
});

// Стандартные парсеры
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Middleware для отладки
app.use((req, res, next) => {
  console.log(`${req.method} ${req.url}`);
  console.log("Headers:", req.headers);
  console.log("Body:", req.body);
  next();
});

// Обслуживание статических файлов
app.use(express.static(path.join(__dirname, "public")));

// Подключаем маршруты
app.use("/auth", authRoutes);
app.use("/products", productRoutes);
app.use("/categories", categoryRoutes);

// Маршрут для корневого URL
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// Обработка ошибок
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: "Что-то пошло не так!" });
});

// Синхронизируем модели с базой данных
sequelize
  .sync({ force: false }) // force: true удалит и пересоздаст таблицы (осторожно!)
  .then(() => {
    console.log("Модели синхронизированы с базой данных");
    const PORT = config.app.port;
    app.listen(PORT, () => {
      console.log(`Сервер запущен на порту ${PORT}`);
    });
  })
  .catch((err) => {
    console.error("Ошибка синхронизации моделей с базой данных:", err);
  });

module.exports = app;
