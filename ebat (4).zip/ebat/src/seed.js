const sequelize = require("./db");
const User = require("./models/User");
const Product = require("./models/Doctor");
const { Purchase } = require("./models/Appointment");
const Category = require("./models/Category");

async function seedDatabase() {
  try {
    await sequelize.sync({ force: true });
    console.log("База данных синхронизирована");

    // Создаем тестовых пользователей
    const users = await User.bulkCreate([
      {
        email: "user1@example.com",
        password: "123456",
        balance: 1000,
      },
      {
        email: "user2@example.com",
        password: "123456",
        balance: 500,
      },
    ]);
    console.log(`Создано ${users.length} пользователей`);

    // Создаем категории
    const categories = await Category.bulkCreate([
      { name: "Программы" },
      { name: "Курсы" },
      { name: "Шаблоны" },
    ]);
    console.log(`Создано ${categories.length} категорий`);

    // Создаем тестовые товары
    const products = await Product.bulkCreate([
      {
        name: "Adobe Photoshop",
        price: 299.99,
        digitalFile: "https://example.com/downloads/photoshop.zip",
        categoryId: 1,
      },
      {
        name: "Курс по JavaScript",
        price: 199.99,
        digitalFile: "https://example.com/downloads/js-course.zip",
        categoryId: 2,
      },
      {
        name: "Шаблон сайта",
        price: 49.99,
        digitalFile: "https://example.com/downloads/template.zip",
        categoryId: 3,
      },
    ]);
    console.log(`Создано ${products.length} товаров`);

    // Создаем тестовую покупку
    const purchases = await Purchase.bulkCreate([
      {
        productId: 1,
        userId: 1,
        price: 299.99,
        purchaseDate: new Date(),
      },
    ]);
    console.log(`Создано ${purchases.length} покупок`);

    console.log("Заполнение базы данных завершено успешно");
  } catch (error) {
    console.error("Ошибка при заполнении базы данных:", error);
  } finally {
    await sequelize.close();
  }
}

seedDatabase();
