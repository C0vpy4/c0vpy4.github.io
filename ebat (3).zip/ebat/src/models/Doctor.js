const { DataTypes } = require("sequelize");
const sequelize = require("../db");

const Scooter = sequelize.define("Scooter", {
  coordinates: {
    type: DataTypes.STRING,
    allowNull: false,
    validate: {
      is: /^-?\d+\.\d+,-?\d+\.\d+$/, // формат: "широта,долгота"
    },
  },
  status: {
    type: DataTypes.ENUM("available", "rented"),
    defaultValue: "available",
    allowNull: false,
  },
});

module.exports = Scooter;
