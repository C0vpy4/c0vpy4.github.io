const { DataTypes } = require("sequelize");
const sequelize = require("../db");

const Rental = sequelize.define("Rental", {
  scooterId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: "Scooters",
      key: "id",
    },
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: "Users",
      key: "id",
    },
  },
  startTime: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW,
  },
  endTime: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  cost: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: true,
  },
});

module.exports = Rental;
