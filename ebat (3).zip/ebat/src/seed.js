const sequelize = require("./db");
const User = require("./models/User");
const Scooter = require("./models/Doctor");
const Rental = require("./models/Appointment");

async function seedDatabase() {
  try {
    await sequelize.sync({ force: true });
    console.log("База данных синхронизирована");

    // Создаем тестовых пользователей
    const users = await User.bulkCreate([
      {
        name: "Иван Иванов",
        phone: "+79001234567",
        password: "123456",
        balance: 1000,
      },
      {
        name: "Петр Петров",
        phone: "+79001234568",
        password: "123456",
        balance: 500,
      },
    ]);
    console.log(`Создано ${users.length} пользователей`);

    // Создаем тестовые самокаты
    const scooters = await Scooter.bulkCreate([
      {
        coordinates: "55.7558,37.6173",
        status: "available",
      },
      {
        coordinates: "55.7517,37.6178",
        status: "available",
      },
      {
        coordinates: "55.7525,37.6231",
        status: "available",
      },
    ]);
    console.log(`Создано ${scooters.length} самокатов`);

    // Создаем тестовую аренду
    const rentals = await Rental.bulkCreate([
      {
        scooterId: 1,
        userId: 1,
        startTime: new Date(),
        endTime: new Date(Date.now() + 30 * 60 * 1000), // +30 минут
        cost: 300, // 30 минут * 10 рублей
      },
    ]);
    console.log(`Создано ${rentals.length} аренд`);

    // Обновляем статус арендованного самоката
    const scooter1 = await Scooter.findByPk(1);
    scooter1.status = "rented";
    await scooter1.save();

    console.log("Заполнение базы данных завершено успешно");
  } catch (error) {
    console.error("Ошибка при заполнении базы данных:", error);
  } finally {
    await sequelize.close();
  }
}

seedDatabase();
