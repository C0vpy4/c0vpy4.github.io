const express = require("express");
const router = express.Router();
const Scooter = require("../models/Doctor");
const Rental = require("../models/Appointment");
const User = require("../models/User");

// Получить список всех самокатов
router.get("/", async (req, res) => {
  try {
    const scooters = await Scooter.findAll();
    res.json(scooters);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Получить список доступных самокатов
router.get("/available", async (req, res) => {
  try {
    const scooters = await Scooter.findAll({
      where: { status: "available" },
      attributes: ["id", "coordinates"],
    });
    res.json(scooters);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Арендовать самокат
router.post("/:id/rent", async (req, res) => {
  try {
    const { userId } = req.body;
    const scooterId = req.params.id;

    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({ error: "Пользователь не найден" });
    }

    if (user.balance < 100) {
      return res.status(400).json({ error: "Недостаточно средств на балансе" });
    }

    const scooter = await Scooter.findByPk(scooterId);
    if (!scooter) {
      return res.status(404).json({ error: "Самокат не найден" });
    }

    if (scooter.status !== "available") {
      return res.status(400).json({ error: "Самокат уже арендован" });
    }

    const rental = await Rental.create({
      scooterId,
      userId,
      startTime: new Date(),
    });

    scooter.status = "rented";
    await scooter.save();

    res.status(201).json(rental);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Завершить аренду
router.post("/:id/end", async (req, res) => {
  try {
    const { userId } = req.body;
    const scooterId = req.params.id;

    const rental = await Rental.findOne({
      where: {
        scooterId,
        userId,
        endTime: null,
      },
    });

    if (!rental) {
      return res.status(404).json({ error: "Аренда не найдена" });
    }

    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({ error: "Пользователь не найден" });
    }

    const endTime = new Date();
    const duration = (endTime - rental.startTime) / (1000 * 60); // в минутах
    const cost = duration * 10; // 10 рублей за минуту

    if (user.balance < cost) {
      return res.status(400).json({ error: "Недостаточно средств на балансе" });
    }

    user.balance = parseFloat(user.balance) - cost;
    await user.save();

    rental.endTime = endTime;
    rental.cost = cost;
    await rental.save();

    const scooter = await Scooter.findByPk(scooterId);
    scooter.status = "available";
    await scooter.save();

    res.json({
      message: "Аренда завершена",
      duration: Math.round(duration),
      cost: cost,
      newBalance: user.balance,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
