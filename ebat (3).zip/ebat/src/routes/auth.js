const express = require("express");
const router = express.Router();
const User = require("../models/User");

// Регистрация
router.post("/register", async (req, res) => {
  try {
    const { name, phone, password } = req.body;

    // Проверяем наличие всех необходимых полей
    if (!name || !phone || !password) {
      return res.status(400).json({
        error: "Все поля обязательны для заполнения",
        details: {
          name: !name ? "Имя обязательно" : null,
          phone: !phone ? "Телефон обязателен" : null,
          password: !password ? "Пароль обязателен" : null,
        },
      });
    }

    // Проверяем формат телефона
    const phoneRegex = /^\+?[0-9]{10,15}$/;
    if (!phoneRegex.test(phone)) {
      return res.status(400).json({
        error: "Неверный формат телефона",
        details:
          "Телефон должен содержать от 10 до 15 цифр и может начинаться с +",
      });
    }

    // Проверяем длину пароля
    if (password.length < 6) {
      return res.status(400).json({
        error: "Пароль слишком короткий",
        details: "Пароль должен содержать минимум 6 символов",
      });
    }

    const user = await User.create({ name, phone, password });
    res.status(201).json({
      message: "Пользователь успешно зарегистрирован",
      userId: user.id,
    });
  } catch (error) {
    if (error.name === "SequelizeUniqueConstraintError") {
      return res.status(400).json({
        error: "Пользователь с таким телефоном уже существует",
      });
    }
    res.status(400).json({ error: error.message });
  }
});

// Вход
router.post("/login", async (req, res) => {
  try {
    const { phone, password } = req.body;
    const user = await User.findOne({ where: { phone } });

    if (!user) {
      return res.status(401).json({ error: "Неверный телефон или пароль" });
    }

    const isValidPassword = await user.validatePassword(password);
    if (!isValidPassword) {
      return res.status(401).json({ error: "Неверный телефон или пароль" });
    }

    res.json({
      message: "Успешный вход",
      userId: user.id,
      balance: user.balance,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Пополнение баланса
router.post("/balance", async (req, res) => {
  try {
    const { userId, amount } = req.body;
    const user = await User.findByPk(userId);

    if (!user) {
      return res.status(404).json({ error: "Пользователь не найден" });
    }

    if (amount <= 0) {
      return res.status(400).json({ error: "Сумма должна быть положительной" });
    }

    user.balance = parseFloat(user.balance) + parseFloat(amount);
    await user.save();

    res.json({
      message: "Баланс успешно пополнен",
      newBalance: user.balance,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
